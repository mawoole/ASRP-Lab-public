"""ASRP Scientific Operating System domain-independent foundation.

Purpose:
    Expose package identity for the ASRP-SciOS foundation.
Responsibilities:
    Identify the implementation version and organize stable public modules.
Inputs:
    None.
Outputs:
    Package version metadata.
Dependencies:
    Python standard library only.
Limitations:
    Sprint-001 supplies contracts, a microkernel, and a local event adapter;
    it is not a complete scientific operating system.
"""

__version__ = "0.1.0"

__all__ = ["__version__"]
